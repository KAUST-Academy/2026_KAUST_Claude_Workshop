Claude-Practice: files for the "How to actually use Claude" workshop
=====================================================================
Everything in this folder is made up. The names, numbers, organisations and
emails are invented for practice. Nothing here is real KAUST information.

01-ask-well   Your turn 1: a made-up annual report to summarise in Chat.
02-skill      Your turn 2: a ready-made skill (meeting-action-items.zip) and
              two sets of made-up meeting notes to try it on.
03-code       Your turn 3 (paid plans): files for Claude Code in the Code tab.
04-cowork     Presenter demo; try it later if you have a paid plan.

01-ask-well and 03-code each have a text-to-copy.txt file with the exact text
to paste, so you don't have to type it.

Keep this folder as your practice folder: when Claude works on files, give it
this folder only, never your whole Documents or home folder.
